import os
import json
import boto3

sns = boto3.client('sns')

def handler(event, context):
    """Pre Sign-up trigger: auto-confirm user and notify admin via SNS."""
    email = event['request']['userAttributes'].get('email', 'unknown')

    # Auto-confirm and auto-verify email
    event['response']['autoConfirmUser'] = True
    event['response']['autoVerifyEmail'] = True

    # Notify admin
    sns.publish(
        TopicArn=os.environ['SNS_TOPIC_ARN'],
        Subject=f'Ollama WebUI — New Access Request: {email}',
        Message=(
            f'A new user has requested access to the Ollama Private LLM platform.\n\n'
            f'Email: {email}\n\n'
            f'To grant access, go to the AWS Cognito Console:\n'
            f'  1. Open Cognito → User Pool → Users\n'
            f'  2. Find the user: {email}\n'
            f'  3. Go to Groups tab → Add to group\n'
            f'  4. Select "user" (standard) or "admin" (full access)\n\n'
            f'The user will be able to access the platform after being added to a group.'
        ),
    )

    return event
