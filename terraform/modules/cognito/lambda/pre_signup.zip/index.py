import os
import json
import boto3

sns = boto3.client('sns')

def handler(event, context):
    """Pre Sign-up trigger: auto-confirm user and notify admin via SNS."""
    email = event['request']['userAttributes'].get('email', 'unknown')

    # Email domain validation — restrict signups to approved domains
    # Set ALLOWED_EMAIL_DOMAINS env var (comma-separated) to enforce.
    # Empty = allow all domains (default, backwards compatible).
    allowed_domains = os.environ.get('ALLOWED_EMAIL_DOMAINS', '').strip()
    if allowed_domains:
        domain = email.split('@')[-1].lower()
        allowed = [d.strip().lower() for d in allowed_domains.split(',') if d.strip()]
        if allowed and domain not in allowed:
            raise Exception(f'Signup restricted to approved email domains')

    # Auto-confirm and auto-verify email
    event['response']['autoConfirmUser'] = True
    event['response']['autoVerifyEmail'] = True

    # Notify admin
    sns.publish(
        TopicArn=os.environ['SNS_TOPIC_ARN'],
        Subject=f'Ollama WebUI — New Access Request: {email}',
        Message=(
            f'A new user has requested access to the Ollama Private LLM platform.\n\n'
            f'Email: {email}\n\n'
            f'To grant access, go to the AWS Cognito Console:\n'
            f'  1. Open Cognito → User Pool → Users\n'
            f'  2. Find the user: {email}\n'
            f'  3. Go to Groups tab → Add to group\n'
            f'  4. Select "user" (standard) or "admin" (full access)\n\n'
            f'The user will be able to access the platform after being added to a group.'
        ),
    )

    return event
