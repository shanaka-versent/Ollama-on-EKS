import os
import json
import boto3

sns = boto3.client('sns')

def handler(event, context):
    """Pre Sign-up trigger: auto-confirm user and notify admin via SNS."""
    email = event['request']['userAttributes'].get('email', 'unknown')

    event['response']['autoConfirmUser'] = True
    event['response']['autoVerifyEmail'] = True

    sns.publish(
        TopicArn=os.environ['SNS_TOPIC_ARN'],
        Subject=f'Grafana — New Access Request: {email}',
        Message=(
            f'A new user has requested access to Grafana.\n\n'
            f'Email: {email}\n\n'
            f'To grant access, go to the AWS Cognito Console:\n'
            f'  1. Open Cognito → User Pool "ollama-grafana" → Users\n'
            f'  2. Find the user: {email}\n'
            f'  3. Go to Groups tab → Add to group\n'
            f'  4. Select "viewer" (read-only) or "admin" (full access)\n\n'
            f'The user will be able to access Grafana after being added to a group.'
        ),
    )

    return event
