import os
import json
import boto3

cognito = boto3.client('cognito-idp')
ses = boto3.client('ses')

def handler(event, context):
    """Notifies user via SES when added to a Cognito group."""
    detail = event.get('detail', {})
    params = detail.get('requestParameters', {})

    username = params.get('username', '')
    group_name = params.get('groupName', '')
    user_pool_id = os.environ['USER_POOL_ID']

    # Get user email from Cognito
    try:
        user = cognito.admin_get_user(
            UserPoolId=user_pool_id,
            Username=username
        )
        email = next(
            (a['Value'] for a in user['UserAttributes'] if a['Name'] == 'email'),
            None
        )
    except Exception as e:
        print(f'Failed to get user: {e}')
        return

    if not email:
        print(f'No email found for user: {username}')
        return

    app_name = os.environ['APP_NAME']
    login_url = os.environ['LOGIN_URL']
    role_desc = 'full access (admin)' if group_name == 'admin' else 'read-only (viewer)'

    try:
        ses.send_email(
            Source=os.environ['SENDER_EMAIL'],
            Destination={'ToAddresses': [email]},
            Message={
                'Subject': {'Data': f'{app_name} — Access Granted'},
                'Body': {
                    'Text': {'Data': (
                        f'Your access to {app_name} (Monitoring Dashboards) has been approved.\n\n'
                        f'Role: {group_name} ({role_desc})\n\n'
                        f'You can now log in at:\n{login_url}\n\n'
                        f'On first login, you will be asked to set up MFA '
                        f'(authenticator app).\n\n'
                        f'If you have any issues, contact your administrator.'
                    )}
                }
            }
        )
        print(f'Access-granted email sent to {email} for {app_name} ({group_name})')
    except Exception as e:
        print(f'Failed to send email via SES: {e}')
        print('Ensure SES sender is verified and account is out of sandbox mode.')
